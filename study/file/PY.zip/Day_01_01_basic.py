# Day_01_01_basic.py


# shift + enter         : 다음줄로 이동
# ctrl + shift +f10     : 실행
# alt + 1               : 각각, 화면 위치 바꿀 수 있음
# alt + 4
# alt + 7

# ctrl + c              : 선택하지 않아도 됨
# ctrl + v
# ctrl + x

# ctrl + /              : 주석 토글
# shicf + arrow         : 여러줄 선택
# tab    vs   shft + tab

# 문제
# Hello python 3가지
print('Hello, python!')
print('Hello, python!')
print('Hello, python!')

print('Hello, python! Hello, python! Hello, python!')

print('Hello, python!'  'Hello, python!'  'Hello, python!')   # 문자열 덧셈

print('Hello, python!', 'Hello, python!', 'Hello, python!')   # 변수 3개 전달

print('Hello, python!' * 3)
print("-" * 50)



# 프로그램 : 편성표
# 구성 : 코드(함수), 데이터(변수)

print(12, 3.14, True, 'hello')
# data type
print(type(12), type(3.14),  type(True), type('hello'))
print("-" * 50)

print('hello small')  # 따옴표 완전히 똑같음
print("hello big")

print('"hello small"')  # 따옴표 완전히 똑같음, 전혀 안 중요함, 구글링하면 다 나옴
print("'hello big'")
print("\"hello big\"")
print("-" * 50)


a = 3
print(a, 3)

# 3 = a      # error,  literal(상수)에 값 할당
print("-" * 50)


# 문제
# a, b 교환
a = 13
b = 6

# 콜라, 주스 교환 -> 빈컵 필요
swap = a
a = b
b = swap
print(a, b)


a, b = 13, 6        #  다중치환, 대입연산자로 여러 개의 변수에
a, b = b, a
print(a, b)


#  연산 : 산술, 관계, 논리
# 산술 : + - * /  ** // %
a, b = 13, 6

print("+", a+b)
print("-", a-b)
print("*", a*b)
print("/", a/b)     # 나눗셈(실수)
print("**", a**b)   # 지수연산
print("//", a//b)   # 나눗셈(정수), 몫 : 2.7에서 지원안함
print("%", a%b)     # 나머지
print("-" * 50)


# 문제
# 두 자리 양수를 뒤집어 보세요
a = 27

a = (a % 10)*10 + (a//10)
print(a)


# 네 자리 양수 뒤집기
a = 1234

a = a%10*1000 + (a//10)%10*100 + (a//100)%10*10 + (a//1000)
print(a)


# 만들어진 코드가 있으면, 가져와서 쓴다
a = 1234
a1 = a // 100
a2 = a % 100

a1 = (a1 % 10)*10 + (a1//10)
a2 = (a2 % 10)*10 + (a2//10)

print(a1 + a2 *100)
print("-" * 50)


s1, s2 = "hello", "python"
print("hello", "python")
print("hello" + "python")
print(s1 + s2)
print("-" * 50)


# 관계 : >  >=  <  <=  ==  !~
a, b = 13, 6
print(a >  b)
print(a >= b)
print(a <  b)
print(a <= b)
print(a == b)
print(a != b)
print("-" * 50)


# 문제
# 나이가 10대인지 알려주세요
age = 15
print(10 <= age <= 19)
print("-" * 50)


# 논리 :  and  or  not
print(True and True)
print(True and False)
print(False and True)
print(False and False)
