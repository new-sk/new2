# Day_01_02_if.py

# 강사에게 배우는 것보다 프로그램에서 배우는 것이 좋을 것이다
# 프로그래머도 사라질 것이다

print("Day_01_02")

a = 7
  # a = 7       # 들여쓰기 되어 있으며, 에러

if a % 2 == 1:      # 모든 문장 가능 : 참 또는 거짓으로 나타나야 ㅏㅎㅁ
    print("홀수")    #  콜론 다음은 들여쓰기가 되어야 함
    print("홀수2,  여러 줄 가능")
#           print("홀수3 들여쓰기 달라서,,,")  # IndentationError: unexpected indent

else:               # else 문장 없어도 됨
    print("짝수")


print(2.5 % 2)


if a % 2:           # "== 1"  n생략 가능, 0 아니면  TRUE
    print("홀수")
else:
    print("짝수")


if a :
    print("홀수")
else:
    print("짝수")
print("-"*50)

# 문제 : 양수, 음수, 0
print("문제 : 양수, 음수, zero 판단?")
a= 0
if a > 0 :
    print("양수")
elif a < 0:
    print("음수")
else:
    print("Zero")

# 코드 보기 어려워짐
if a > 0 :
    print("양수2")
else:
    if a < 0:
        print("음수2")
    else:
        print("Zero2")
print("-"*50)

# white space : space, tab, enter

# 문제 : hello를 n번 출력, if사용, (0<=n<=3)
n = 3
print(n, "hello's")
if n<0 or n>3:
    print(n,"not allowed number (0~3 integer)")
elif n==1:
    print("hello")
elif n==2:
    print("hello")
    print("hello")
elif n == 3:
    print("hello")
    print("hello")
    print("hello")

# 참고
print("hello" * n)
print("-"*50)


if n==1:
    print("hello")
elif n==2:
    print("hello")
    print("hello")
elif n == 3:
    print("hello")
    print("hello")
    print("hello")
print("-"*50)

# n : (남아있는) 출력할 횟수
# 코드가 길어져도 똑같은 내용 계속 사용 가능
n = 2
if n > 0:
    print("hello")
    n -= 1
if n > 0:
    print("hello")
    n -= 1
if n > 0:
    print("hello")
    n -= 1
if n > 0:
    print("hello")
    n -= 1
print("-"*50)


# i : 출력한 횟수
# n : 출력할 횟수
i, n = 0,2
if i < n:
    print("hello")
    i += 1
if i < n:
    print("hello")
    i += 1
if i < n:
    print("hello")
    i += 1
print("-"*50)


i, n = 0,20
while i < n:
    print("hello")
    i += 1
