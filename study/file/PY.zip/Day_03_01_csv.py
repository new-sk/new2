# Day_03_01_csv.py
import csv


def read_csv_1():
    f = open('Data/weather.csv', 'r', encoding='utf-8')

    rows = []
    for row in f:
        #print(row.strip().split(','))
        rows.append(row.strip().split(','))

    f.close()

    return rows


def read_csv_2():
    f = open('Data/us-500.csv', 'r', encoding='utf-8')

    # skip.header
    f.readline()

    for row in csv.reader(f):
        print(row)

    f.close()


def write_weather():
    rows = read_csv_1()

    # newline : csv file 쓸 때 빈 줄 삽입되는 것 방지
    f = open('Data/weather2.csv', 'w', encoding='utf-8', newline='')

    writer = csv.writer(f, delimiter=':', quoting=csv.QUOTE_ALL)

    for row in rows:
        # print(row)
        writer.writerow(row)

    f.close()


if __name__ == '__main__':
    #read_csv_1()
    # read_csv_2()
    write_weather()

    # us-500.csv        # csv file 참고 자료료