# Day_02_04_weather.py

import re
import requests
import Day_02_05_file   # 다른 파일 내용 가져올 수 있음

f = open('Data/weather.csv', 'w', encoding='utf-8')

# 방법 1 : 로컬 파일
text = Day_02_05_file.read_text('Data/weather.xml')
#print(text)

# 방법2 : 온라인 파일
# url = 'http://www.kma.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=108'
# recevied = requests.get(url)
# # print(recevied.text)

# htmㅈ : user interface
# xml : user if 제거
# rss : xml의 한 가지 형태

# XML : 전체 문서에서 태그가 유일함

# temp = re.findall(r'<province>(.+?)</province>', recevied.text)
# print(temp)
# print(len(temp))

# 문제
# Locations를 찾아보세요.
# re.DOTALL : 찾으려는 대상이 여러 줄에 걸쳐 있을 때
# 파일
locations = re.findall(r'<location wl_ver="3">(.+?)</location>', text)     # 기본 옵션은 같은 줄에서 찾음
locations = re.findall(r'<location wl_ver="3">(.+?)</location>', text, re.DOTALL)     # 멀리 떨어진 것도 찾음
# 온라인
# locations = re.findall(r'<location wl_ver="3">(.+?)</location>', recevied.text)     # 기본 옵션은 같은 줄에서 찾음
# locations = re.findall(r'<location wl_ver="3">(.+?)</location>', recevied.text, re.DOTALL)     # 멀리 떨어진 것도 찾음
# # print(len(locations), locations)

for loc in locations:
    # print(loc)

    # 문제
    # province와 city를 찾아보세요
    prov = re.findall(r'<province>(.+)</province>',loc)
    city = re.findall(r'<city>(.+)</city>',loc)
    # 밑에서 출력 : 중복된 데이터 만듦
    # print(prov[0],city[0])

    # 문제
    # data를 찾아보세요
    data = re.findall(r'<data>(.+?)</data>',loc, re.DOTALL)     # 재차 강조 : ?, re.DOTALL
    # print(len(data), data)

    # 문제
    # mode, tmEf, wf, tmn, tmx, reliability
    for tt in data:                                     # MY ERROR : range(len(data))
        # mode = re.findall(r'<mode>(.+)</mode>',tt)
        # tmEf = re.findall(r'<tmEf>(.+?)</tmEf>',tt)
        # wf = re.findall(r'<wf>(.+?)</wf>',tt)
        # tmn = re.findall(r'<tmn>(.+?)</tmn>',tt)
        # tmx = re.findall(r'<tmx>(.+?)</tmx>',tt)
        # reliability = re.findall(r'<reliability>(.+?)</reliability>',tt)
        # print(mode[0], tmEf[0], wf[0], tmn[0], tmx[0], reliability[0])

        items = re.findall(r'<.+>(.+)</.+>', tt)        # Wow
        # print(len(items), items
        print(prov[0],city[0], items[0], items[1], items[2], items[3], items[4], items[5])

        row = '{},{},{},{},{},{},{},{}\n'.format(prov[0],city[0], items[0], items[1], items[2], items[3], items[4], items[5])
        f.write(row)

f.close()


# <mode>A02</mode>
# <tmEf>2018-06-19 00:00</reliability>
# <wf>구름조금</wf>
# <tmn>20</tmn>
# <tmx>28</tmx>
# <reliability>보통</reliability>

# 제주도 서귀포
# A02 2018-06-19 00:00 구름많음 21 27 보통
# A02 2018-06-19 12:00 구름많음 21 27 보통
# -->
# 제주도 서귀포 A02 2018-06-19 00:00 구름많음 21 27 보통
# 제주도 서귀포 A02 2018-06-19 12:00 구름많음 21 27 보통
