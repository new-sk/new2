# Day_02_01_loop

# 반복 : 동일한 코드
# 1 3 5 7 9         1, 9, 2
# 0 2 4 6 8         0, 8, 2
# 4 3 2 1 0         4, 0, -1

i = 1
while i <= 9:
    print("blabla", i)
    i += 2

for i in range(0,5,1):      # 시작, 종료, 증감  (5번 반복, collection은 0부터 시작), 종료조건 포함하지 않음
    print(i, end=' ')       # end 옵션으로 오른쪽으로 출력
print()

for i in range(0, 5):       # 시작, 종료, 1
    print(i, end=' ')
print()

for i in range(5):          # 0, 종료, 1     (젤 많이 사용함)
    print(i, end=' ')  # end 옵션으로 오른쪽으로 출력
print()

# 문제
# 0-24까지의 정수 출력, 거꾸로 출력
for i in range(25):
    print(i, end=' ')
print()

for i in range(24,-1,-1):
    print(i, end=' ')
print()

# 위의 코드 쉽게 만든 것임
for i in reversed(range(25)):
    print(i, end=' ')
print()


# 문제
# 0-24까지의 정수 출력
# 한 줄에 5개씩
pi = 0
for i in range(25):
    print(i, end=' ')
    pi += 1
    if pi%5 == 0: print()
print()

pi = 0
for i in reversed(range(25)):
    print(i, end=' ')
    pi += 1
    if pi%5 == 0: print()


# 행, 열 index로 만들면 좋을 듯
print("-"*50)
for i in range(5):
    for j in range(5):
        print(i*5+j, end=' ')
    print()
print()

for i in zip(list(range(5)), list(reversed(range(5)))):
    print(i)