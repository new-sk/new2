# Day_02_03_json.py

import json     # 문자열로 변환해서 전달 : java script object natation
import requests


# https://www.jsontest.com/

def json_1():
    j1 = '{"ip": "8.8.8.8"}'
    print(type(j1), j1)

    j2 = json.loads(j1)   # load <--> dump,
    print(type(j2), j2)

    # 문제
    # 딕셔너리를 문자열로 변환해 보세요
    j3 = json.dumps(j2)
    print(type(j3), j3)
    print("-" * 50)


def json_2():
    url = 'http://www.kma.go.kr/DFSROOT/POINT/DATA/top.json.txt'  # 한글 인코딩 문제, 깨짐
    received = requests.get(url)
    text = received.content.decode('utf-8')  # utf-8 이 대세지만, 다른 것 쓰는 사이트 있음, 일일이 찾아야지만 됨
    print(type(text), text)


    # 문제
    # 지역 코드와 이름만 출력해 보세요
    j1 = json.loads(text)                   # 파싱하면 어떤 타입인지 알겠죠
    print(type(j1), j1)
    # print(j1[code],j1[value])
    for i in j1:                            # 리스트이니깐, loop 사요
        print(i['code'], i['value'])        # dictionary로 보이니깐, 요렇게,,,

json_2()

