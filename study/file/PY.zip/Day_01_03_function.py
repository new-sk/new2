# Day_01_03_function

print("print :", print)

# 팀장, 팀원
# 관련이 있는 사람들 : 같은 프로젝트 수행 : 팀장이 역할 분담, 팀원 역할 수행/보고
# 팀장 --> 데이터(매개변수) --> 팀원     # 데이터의 순환
# 팀장 <-- 데이터(반환값)  <-- 팀원


a = 3
print(a)   # a는 팀장꺼, 팀원은 복사하여 새로 만듦

# 매개변수 X,  반환값 X
def f_1():          # 함수를 정의한다
    print('f_1')

f_1()               # 함수를 호출한다


# 매개변수 O,  반환값 X
def f_2(b):          # 함수를 정의한다
    print("f_2", b)

f_2("123")               # 함수를 호출한다,  b를 알려줘야지만 일을 할 수 있는 팀원이다


print("문제 : f_2를 호출하는 두 가지 코드를 찾아보세요")
def f_2(a,b):          # 함수를 정의한다
    print("f_2_problem", a+b)

f_2(12,34)               # 함수를 호출한다,  b를 알려줘야지만 일을 할 수 있는 팀원이다
f_2("12","34")
#f_2(12,"34")            # error


# 매개변수 X,  반환값 O
def f_3():          # 함수를 정의한다
    pass

a = f_3()               # 함수를 호출한다
print(a)            # 함수내역을 pass로 되어 있어도, 파이썬은 에러나지 않음


def f_31():          # 함수를 정의한다
    return 17

a = f_31()           # 함수를 호출한다
print(a)

print(f_31())
print("-"*50)

# 매개변수 O,  반환값 O
# 문제 : 두 개의 정수 중에서 큰 숫자를 찾는 함수
# 함수 이름은 max2로 합니다.

def max2(a,b):
    if (a>b) :
        x = a
    else:
        x=b
    return x        # One Entry One Exit (가능하면,,,)

print( max2(5,100-2) )


# 문제 : 4개의 정수 중에서 큰 숫자를 찾는 함수
# 함수 이름은 max4로 합니다.

def max4(a,b,c,d):
    # # 방법1
    # if a < b: a = b     # 한 줄인 경우 옆에 적을 수 있음
    # if a < c: a = c
    # if a < d: a = d
    # return a

    # 방법2 : 복면가왕
    # return (max2(max2(a, b), max2(c, d)))

    # 방법3 : 한국시리즈
    return max2(max2(max2(a,b),c),d)   #   방법2보다 유연함, 방법2는 2의 배수여야 함,,,

print( max4(1,2,3,4) )



# file 서버
# http://192.168.0.19/python/