# Day_03_02_function.py

#########################################
# CTRL + mouse click : 함수 설명 내역 보임
#########################################

def functions():
    # positional vs keyword argument
    def f_1(a,b,c):
        print(a,b,c, end='\n', sep='++')


    f_1(1,2,3)          # positional argument
    f_1(a=1, b=2, c=3)  # keyword argument
    f_1(c=3, a=1, b=2)  ## 순서 바꿀 수 있음
    f_1(1, b=2, c=3 )   ## 두가지 방법 모두 사용 가능
    # f_1(a=1, 2, c=3 )   ## ERROR : positional은 keyword 앞에만 가능


    # default argument
    def f_2(a=0, b=0, c=0):
        print(a,b,c)


    f_2()
    f_2(1)
    f_2(1,2)
    f_2(b=1)

    # 함수 안의 함수 가능
    #   단, 안의 함수는 다른 곳에서 사용 불가


    def f_3(*args):     # 가변인자
        print(args)
        print(args, *args)  # unpack (force) : 강제로 unpack해 줌


    f_3()
    f_3(1)
    f_3(1, 2.3)
    f_3(1, 2.3, '안녕')   # pack : 3개 전달했는데, 1개로 이해함

    d = [1,3,6]
    print(d, *d)        # 일반문장에서도 *를 활용한 unpack 가능

def f_4(**kwargs):      # keyword 가변인자
    print(kwargs)

f_4()
f_4(a=1)
f_4(a=1, b=2)