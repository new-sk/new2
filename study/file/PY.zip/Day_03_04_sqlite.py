# Day_03_04_sqlite.py
import sqlite3      # 파일 기반 데이터베이스, 모바일쪽 활용, iOS는 요즘 사용안함
import Day_03_01_csv  # 다른 파일 내역 가져옴

def create_db():
    conn = sqlite3.connect('Data/weather.sqlite')
    cur = conn.cursor()

    query = 'CREATE TABLE weather (prov TEXT, city TEXT, mode TEXT, tmEf TEXT, wf TEXT, tmn TEXT, tmx TEXT, reliability TEXT)'
    cur.execute(query)

    conn.commit()
    conn.close()


# def insert_row(rows):
#     conn = sqlite3.connect('Data/weather.sqlite')
#     cur = conn.cursor()
#
#     base = 'INsert into weather values("{}","{}","{}","{}","{}","{}","{}","{}")'
#     query = base.format(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7])
#     cur.execute(query)
#
#     conn.commit()
#     conn.close()


def insert_all(rows):
    conn = sqlite3.connect('Data/weather.sqlite')
    cur = conn.cursor()

    base = 'INsert into weather values("{}","{}","{}","{}","{}","{}","{}","{}")'

    for row in rows:
        # query = base.format(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7])
        query = base.format(*row)       # 참고 : 전체 사용해야 하고, 순서 못바꿈
        cur.execute(query)

    conn.commit()
    conn.close()


def fetch_all():
    conn = sqlite3.connect('Data/weather.sqlite')
    cur = conn.cursor()

    query = 'select * from weather'
    for row in cur.execute(query):
        print(row)

    # conn.commit()     # select문이니깐, 의미없는 문장임
    conn.close()


# 문제
# 부산 데이터만 가져오는 함수를 만드세요
# 이름 : search_city
def search_city(city):
    conn = sqlite3.connect('Data/weather.sqlite')
    cur = conn.cursor()

    base = 'select * from weather where city = "{}"'
    query = base.format(city)

    rows = []
    for row in cur.execute(query):
        print(row)
        rows.append(row)

    conn.close()

    return rows


if __name__ == '__main__':

    #create_db()

    #rows = Day_03_01_csv.read_csv_1()
    # print(*rows, sep='\n')

    # for row in rows:
    #     insert_row(row)
    #
    #insert_all(rows)
    #
    # fetch_all()
    #
    # # 파이썬하고는 상관없음, sqlite 문제임
    # # sqlite3 사용법 : 헤르메스 : 구글링 참고
    #

    search_city('부산')

