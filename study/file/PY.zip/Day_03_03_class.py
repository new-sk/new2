# Day_03_03_class.py

class Info:
    def __init__(self):
        print('생성자')
        self.name = 'hoon'

    def show(self):
        print('show :', self.name)

i1, i2 = Info(), Info()     # pass로 아무것도 없어도 만들어짐
print(i1)

# 문제
# show 함수를 호출해 보세요
# show()  : ERROR : name 'show' is not defined
# Info.show(12)
#Info.show(i1)   # unbound method : 기본적으로 자기가 호출됨
i1.show()       # bound method : 다른 언어에서 제공하는 호출 방법 (객체와 함수 연결하여 사용)
i2.show()

a = [3,6,1,2]

#a.sort()
list.sort(a)

print(a)