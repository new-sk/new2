# Day_03_06_slicing.py

a = list(range(10))
print(a)

print(a[len(a)-1], a[len(a)-2])
print(a[-1], a[-2])             # 음수를 사용하여 뒤에서부터 접근 가능

print(a[3:7])          # slicing. range()와 사용법이 동일함

#문제
# 앞쪽 절반, 뒷쪽 절반 출력
print(a[0:5])
print(a[:5])
print(a[5:10])
print(a[5:])

# 처음부터 끝까지 2칸씩 건너뛰며 출력
print(a[0:10:2])
print(a[::2])

# 문제
# 거꾸로 출력
print(a[3:4])
print(a[3:3])
print(a[9:-1:-1])
print(a[-1:-1:-1])
print(a[::-1])      # CORRECT,  양수(정방향) / 음수(역방향)

