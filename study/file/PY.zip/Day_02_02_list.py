# Day_02_02_list.py

# collection : list, tuple, set, dictionary
#              []    ()     {}    {}


a = [1,3,5, 'hello']              # 다른 타입이 들어갈 수 있어서 배열이 아니다.
print(a)
print(a[0], a[1], a[2])  # 연속된 공간, 한 가지 타입만 존재
print("-"*50)

for i in range(len(a)):     # range
    print(a[i], end=' ')
print()

# 전체 자료 다 읽어야 함
for i in a:                 # list   :   iterable하면 for문에 쓸 수 있다
    print(i, end=' ')
print()
print("-"*50)

# 문제
# 리스트를 거꾸로 출력해 보세요  (2가지 방법)
for i in reversed(range(len(a))):     # range
    print(a[i], end=' ')
print()

for i in reversed(a):                 # list   :   iterable하면 for문에 쓸 수 있다
    print(i, end=' ')
print()
print("-"*50)


# tuple
t = (1,3,5)
print(t)
print(t[0], t[1], t[2])
print(type(t))
print("-"*50)

# tuple : 상수 버전의 list
# t[0] = 99    # error : tuple에서는 작동하지 않음 : 'tuple' object does not support item assignment
# t.append(99) # error : 'tuple' object has no attribute 'append'

t1 = (2, 8)
print(t1)

t2 = 2,8                    # pack
print(t2, t2[0], t2[1])
print()

t3, t4 = 2, 8
print(t3,t4)
print()

t3, t4 = t2                 # unpack
print(t3,t4)
print("-"*50)
# t5, t6, t7 = 2, 4         # error   : not enough values to unpack (expected 3, got 2)

# 리스트에서 출력 예제 했음

# ''' 항수 바로 아래에 만듦 : help : 기본이 뜸'''
def dummy(a1, a2):
    '''
    그냥 함수
    :param a1: 정수1
    :param a2: 정수2
    :return: 다중 변환 구현
    '''
    return a1 - a2, a1 + a2

help(dummy)

t5, t6 = dummy(3,8)
print(t5, t6)
print()

t7 = dummy(3,8)
print(t7, t7[0], t7[1])
print()

t8, _ = dummy(3,8)      # place holder
print(t8)
print()
print("-"*50)



# dictionary
d1 = {}
d2 = {12}
d3 = {12:34}
print(type(d1))
print(type(d2))
print(type(d3))

# 영한사전 : 영어 단어를 찾으면 한글 설명 나옴
# 영어단어(key), 한글 설명(value)
#      key    value
d = { "name":"hoon", "age":20}  # 표현법 1
d = dict(name="hoon", age=20)   # 표현법 2
print(d)
print(d["name"], d["age"])      # list는 정수,  dictionary는 value

d['addr'] = "수지"    # 추가(insert)
print(d)
print()

d["addr"] = "서초"    # 변경(update) : 이사갔네요
print(d)
print()

print(d.items())

# 문제
# items 함수를 for문과 연동하여 사전 내용을 출력해 보세요
for key,value in d.items():     # tuple 리턴하므로 변수 2개 사용하여 받으면 좋다
    print(key,value)
print()

for k in d:
    print(k, d[k])
