# Day_02_05_file

def read_1():
    f = open('Data/poem.txt', 'r', encoding='utf-8')
    lines = f.readlines()   # 개행문자도 있음
    print(lines)

    for i in lines:
        # print(i, end='')
        print(i.strip())    # 양쪽 공백들 제거 : space, tab, 개행문자

    f.close()


def read_2():
    f = open('Data/poem.txt', 'r', encoding='utf-8')

    while True:     # 무한루프
        line = f.readline()

        # 거짓 : False, 0, 0.0, None, ''(길이가 0인 문자), [](비어있는 리스트)
        # if(len(line)==0):
        #if not len(line):       #  다른 사람들이 많이 쓰더라
        if not line:
            break

        print(line.strip())

    f.close()


def read_3():
    f = open('Data/poem.txt', 'r', encoding='utf-8')

    lines = []
    for line in f:
        # print(line.strip())
        lines.append(line.strip())

    f.close()

    return lines


def read_4():
    with open('Data/poem.txt', 'r', encoding='utf-8') as f:
        for line in f:
            print(line.strip())

    f.close()


def write_1():
    f = open('Data/write.txt', 'w', encoding='utf-8')

    f.write("hello!!!!" + "\n")
    f.write("python")

    f.close()


def read_text(filename):
    f = open(filename, "r", encoding="utf-8")
    lines = f.readlines()
    f.close()

    return ''.join(lines)   # 문자열 변수를 매개변수로 전달


# Day_02_05_file : import 되었을 때
# __main__ : import 되지 않았을 때 (첫번째 로딩 파일)
print(__name__)         # 파이썬에서 자체적으로 사용하는 조심해서 사용해야 하는 변수로 파일마다 하나씩 존재함

if __name__ == "__main__":
    # read_1()
    read_2()
    # print( read_3() )
    # read_4()
    # write_1()

    # import Day_02_05_file   # 다른 파일 내용 가져올 수 있음