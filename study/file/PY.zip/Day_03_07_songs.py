# Day_03_07_songs.py

import re
import requests

# S_PAGENUMBER: 2
# S_MB_CD: W0726200
# S_HNAB_GBN: I
# hanmb_nm: G-DRAGON

def show_songs(code, page):
    payload = {'S_PAGENUMBER': page,
               'S_MB_CD': code}
    # payload = {'S_PAGENUMBER': 2,
    #            'S_MB_CD': 'W0726200',
    #            'S_HNAB_GBN': 'I',
    #            'hanmb_nm': 'G-DRAGON'}

    url = 'https://www.komca.or.kr/srch2/srch_01_popup_mem_right.jsp'
    received = requests.post(url, data=payload)
    # print(received.text)

    tbody = re.findall(r'<tbody>(.+?)</tbody>', received.text, re.DOTALL)
    # print(len(tbody))
    # print(tbody[0])

    trs = re.findall(r'<tr>(.+?)</tr>', tbody[0], re.DOTALL)      # MY ERROR : tbody --> tbody[0]
    # print(len(songs))

    if not trs:
        return False

    for tr in trs:
        # print(tr)

        # 중요 : 바꾸기 기능 : 이미지 부분 찾아서 없애기
        # tr = re.sub(r'<img src="/images/common/control.gif"  alt="" />', '', tr)  # 잘 안바뀌는 것이 있ㄴ
        tr = re.sub(r' <img(.*?)/>', '', tr)        # 개발자가 스페이스 넣었음
        tr = re.sub(r'<br/>', ',', tr)

        tds = re.findall(r'<td>(.*?)</td>',tr)      # 중요 : 없는 것도 있어요. *로 쓰면 모두 5개의 속성을 가지게 됨
        tds = [td.strip() for td in tds]
        print(tds)
        # print(len(tds))

    return True

    # get :  주소, 궁금한 것 물어보는 방식 ?
    # 제한 있음, 오픈되어 있음

    # post
    #  ctrl+shift+i
    # 네트워크
    # 헤더 - General - request Method
    #  헤더 - request header
    # 헤더 - Form Data : 실제데이터


show_songs('W0726200', 1)   # 10000없는 페이지 조회해서 결과 내역 확인

page = 1
while show_songs('W0726200', page):
    print('----------',page)
    page += 1


# 강사
# apple  김정훈
# 공지사항 젤 마지막 로긴