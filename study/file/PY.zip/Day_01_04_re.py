# Day_01_04_re.py
import re       # 파이썬 설치시 같이 설치됨,  import 정규식

# 문자열의 검색과 치환

# 정규표현식 6개
# . : 1개 글자               ---> ... : 글자 3개
# [] : 여러 글자 중 1개 글자  --> [abc], [a-z
# [^] : 부정
#
# 앞의 것의 횟수 지정
# ? : 0,1
# * : 0번 이상
# + : 1번 이상

# 웹에서 Regex Cross­word 검색

# 3412 BOB 123          # 구글링

# ''' 여러 줄 문자열
# 이쁘게 만들고 싶다. --> 그냥 이렇게 두고 쓰세요. : 별다른 방법 없어요
db = '''3412    [Bob] 123         
3834  Jonny 333
1248   Kate 634
1423   Tony 567
2567  Peter 435
3567  Alice 535
1548  Kerry 534'''

# r : raw의 약자
temp = re.findall(r'[0-9]', db)
print(temp)

numbers = re.findall(r'[0-9]+', db)
print(numbers)


# 문제
# 이름만 찾아보세요
print("Ploblem Name")
names = re.findall(r'[A-Z][a-z]*', db)
print(names)

# re.findall(r'[a-Z]+', db)  #error  : 큰 숫자가 먼저
# re.findall(r'[A-z]+', db) #bug
# re.findall(r'[A-Za-z]+', db) #normal
# re.findall(r'[A-Z|a-z]+', db) #bug  : |
# re.findall(r'[A-Z][a-z]+', db) #good




# 둘째날 시작
# 문제
# T로 시작하는 이름만 찾아보세ㅇ.
# T로 시작하지 않는 이름만 찾아보세요.

print("3",re.findall(r'[T][a-z]+', db))
# 그냥 T라고 하면 되지 : r'T[a-zA-Z]+'
print("4",re.findall(r'[A-SU-Z][a-z]+', db))

print("5",re.findall(r'[^T][a-z]+', db))    # Error : ony
print("6",re.findall(r'[^T][a-zA-Z]+', db))    # Error : ' Tony'




import requests  # 따로 설치해야 함 file-setting 크롤링 등 활용
# re_basic()

def re_areacode():
    # url = 'http://www.naver.com'
    url = 'http://www.kma.go.kr/DFSROOT/POINT/DATA/top.json.txt'    # 한글 인코딩 문제, 깨짐
    received = requests.get(url)
    print(received)                 # 200 정상접속,  404 : not found
    print(received.text)
    print(received.content)         # 바이트값 보여줌, ASCII값은 보여주고, 아니면 바이트값으로 보여줌

    text = received.content.decode('utf-8')     # utf-8 이 대세지만, 다른 것 쓰는 사이트 있음, 일일이 찾아야지만 됨
    print(text)

    # 문제
    # 코드와 지역 이름만 출력해 보세요
    # [{"code":"11","value":"서울특별시"},{"code":"26","value":"부산광역시"},{"code":"27","value":"대구광역시"},{"code":"28","value":"인천광역시"},{"code":"29","value":"광주광역시"},{"code":"30","value":"대전광역시"},{"code":"31","value":"울산광역시"},{"code":"41","value":"경기도"},{"code":"42","value":"강원도"},{"code":"43","value":"충청북도"},{"code":"44","value":"충청남도"},{"code":"45","value":"전라북도"},{"code":"46","value":"전라남도"},{"code":"47","value":"경상북도"},{"code":"48","value":"경상남도"},{"code":"50","value":"제주특별자치도"}]

    # 나의 시도 실패
    # print("A", re.findall(r'"code":"..',text))
    # print("B", re.findall(r'[0-9]+', re.findall(r'"code":"..',text)))

    # 1안) 일반적이지 않다
    # codes = re.findall(r'[0-9]+',text)
    # print("C", codes)
    # areas = re.findall(r'[가-힣]+',text)
    # print("D", areas)

    # 2안) 좋지만, 일반적이지 않다. 두자리 숫자가 아닐 수도 있어야 함
    # codes = re.findall(r'"code":"([0-9]+)"',text)   # 파이썬, ()로 감싸주면 이것만 표시해줌
    # print("E", codes)
    # areas = re.findall(r'"value":"([가-힣]+)"',text)
    # print("F", areas)

    # .+  : 탐욕적(greedy)
    # .+? : 비탐욕적(non-greedy)
    # codes = re.findall(r'"code":"(.+)"',text)   # bug .+ --> 마지막 "을 찾을 때까지 기다림
    codes = re.findall(r'"code":"(.+?)"',text)    #  .+? --> 첫번째 찾으면 멈추네요.
    print("G", codes)
    areas = re.findall(r'"value":"([가-힣]+)"',text)
    print("H", areas)

    # 문제
    # 이름 왼쪽에 번호를 붙여 주세요
    # for i in areas:
    #     print(i)

    # for i in range(len(areas)):
    #     print(i, areas[i])
    #
    # for name in enumerate(areas):
    #     print(name, name[0], name[1])

    for i, name in enumerate(areas):
        print('{:02} {}'.format(i, name))       #  format : 원하는 형식으로 출력 : 매개변수 갯수만큼 중간괄호 필요{}
                                            # {2} : 매개변수 순서임
                                            # ":2" 중요 : 자릿수 표시임


re_areacode()

# 정규표현식 : 더 낫다고 생각한다. 로그 분석 등 일반적인 활용범위, 사용하기 쉽다.
# 뷰티블 수프 : 구글링,

