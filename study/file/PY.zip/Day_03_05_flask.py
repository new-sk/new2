# Day_03_05_flask.py

# static, templates

# 파이콘 2018 8.17 시간되면 가 보세요

from flask import Flask, render_template
import random
import Day_03_04_sqlite


app = Flask(__name__)


def make_randoms(count, limit):
    numbers = []
    for i in range(count):
        # print(random.randrange(limit))
        numbers.append(random.randrange(limit))

    return numbers

@app.route('/')       # 매핑
def index():
    return 'hello, flask!!'

@app.route('/randoms')
def randoms():
    a = make_randoms(10,100)
    return str(a)               # 문자열로 제공되어야 함

# 문제
# 두번째 이미지를 매개변수로 전달해서 웹 페이지에 표시해보세요
@app.route('/image')
def image():
    a = make_randoms(10,100)
    return render_template('randoms.html', number=a)   # render : 내가 전달한 내역을 그려줌

# 문제
# 두번째 이미지를 매개변수로 전달해서 웹 페이지에 표시해보세요
@app.route('/image')
def image2(img_nm):
    a = make_randoms(10,100)
    return render_template('randoms.html', number=a, img_nm='image2.jpg')   # render : 내가 전달한 내역을 그려줌

@app.route('/board')
def board():
    page = 0
    start = page * 5
    end = start + 5
    items = Day_03_04_sqlite.search_city('부산')
    return render_template('board.html', items=items[start:end])   # [:5] 앞의 5개만 보여줌


if __name__ == '__main__':
    app.run(debug=True)         # 개발서버 : 서버끄지 않아도 적용  # 공유기의 DDNS 통해서


# {{data}} : HTML 데이터표시
# {% 파이썬코드 %}
# {% endfor %}

# 구글링 : python flask : http://flask-docs-kr.readthedocs.io/ko/latest/quickstart.html
# 구글링 : 예쁜 홈페이지 : 단순한 홈페이지 복사해서
# 구글링 : 장고 : https://tutorial.djangogirls.org/ko/django/  (CSS 예쁘게 만들기)
# flask로 시작해서 장고로 끝을 내면 됩니다