# Day_01_04_re.py
import re       # 파이썬 설치시 같이 설치됨,  import 정규식
import requests  # 따로 설치해야 함 file-setting 크롤링 등 활용

def re_areacode():
    url = 'http://blog.daum.net/b2ttlovesss/22'
    received = requests.get(url)
    print(received)                 # 200 정상접속,  404 : not found
    print(received.text)
    print(received.content)         # 바이트값 보여줌, ASCII값은 보여주고, 아니면 바이트값으로 보여줌

    text = received.content.decode('utf-8')     # utf-8 이 대세지만, 다른 것 쓰는 사이트 있음, 일일이 찾아야지만 됨
    print(text)

    # 문제
    # 코드와 지역 이름만 출력해 보세요
    # [{"code":"11","value":"서울특별시"},{"code":"26","value":"부산광역시"},{"code":"27","value":"대구광역시"},{"code":"28","value":"인천광역시"},{"code":"29","value":"광주광역시"},{"code":"30","value":"대전광역시"},{"code":"31","value":"울산광역시"},{"code":"41","value":"경기도"},{"code":"42","value":"강원도"},{"code":"43","value":"충청북도"},{"code":"44","value":"충청남도"},{"code":"45","value":"전라북도"},{"code":"46","value":"전라남도"},{"code":"47","value":"경상북도"},{"code":"48","value":"경상남도"},{"code":"50","value":"제주특별자치도"}]

    # 나의 시도 실패
    # print("A", re.findall(r'"code":"..',text))
    # print("B", re.findall(r'[0-9]+', re.findall(r'"code":"..',text)))

    # 1안) 일반적이지 않다
    # codes = re.findall(r'[0-9]+',text)
    # print("C", codes)
    # areas = re.findall(r'[가-힣]+',text)
    # print("D", areas)

    # 2안) 좋지만, 일반적이지 않다. 두자리 숫자가 아닐 수도 있어야 함
    # codes = re.findall(r'"code":"([0-9]+)"',text)   # 파이썬, ()로 감싸주면 이것만 표시해줌
    # print("E", codes)
    # areas = re.findall(r'"value":"([가-힣]+)"',text)
    # print("F", areas)

    # .+  : 탐욕적(greedy)
    # .+? : 비탐욕적(non-greedy)
    # codes = re.findall(r'"code":"(.+)"',text)   # bug .+ --> 마지막 "을 찾을 때까지 기다림
    # codes = re.findall(r'"code":"(.+?)"',text)    #  .+? --> 첫번째 찾으면 멈추네요.
    # print("G", codes)
    # areas = re.findall(r'"value":"([가-힣]+)"',text)
    # print("H", areas)

re_areacode()

# 정규표현식 : 더 낫다고 생각한다. 로그 분석 등 일반적인 활용범위, 사용하기 쉽다.
# 뷰티블 수프 : 구글링,

# 김성훈 교수 페이스 : 모두를 위한 딥러닝